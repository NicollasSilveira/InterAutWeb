create database Interaut;
USE Interaut;
CREATE TABLE Pessoa (
    idPessoa INT AUTO_INCREMENT PRIMARY KEY,
    dataNasc VARCHAR(10),
    tel VARCHAR(15),
    email VARCHAR(45),
    genero INT,
    tipoPessoa INT,
    tipoTratamento VARCHAR(50),
    login VARCHAR(150),
    senha VARCHAR(400),
    tokenPush VARCHAR(400),
    isAtivo TINYINT
    );
    CREATE TABLE aluno(
    idAluno INT AUTO_INCREMENT PRIMARY KEY,
    nomeAluno VARCHAR(50),
    dataNasc VARCHAR(10),
    genero INT,
    isAtivo TINYINT
    );

CREATE  TABLE PessoaAluno (
idPessoaAluno INT PRIMARY KEY AUTO_INCREMENT,
idPessoa INT ,
idAluno VARCHAR (10),
isAtivo TINYINT
);

CREATE TABLE categoriaInteracao(
idCategoriaInteracao int(6) PRIMARY KEY,
url VARCHAR (400),
descricao VARCHAR(50),
isAtivo TINYINT
);

CREATE TABLE imagemCategoria (
    idImagemCategoria INT PRIMARY KEY,
    descricao VARCHAR(150),
    url VARCHAR(400),
    fala VARCHAR(100),
    idCategoriaInteracao INT,
    isAtivo TINYINT,
    FOREIGN KEY (idCategoriaInteracao) REFERENCES categoriaInteracao(idCategoriaInteracao)
);

create TABLE registroInteracoes (
    idRegistroInteracoes INT PRIMARY KEY AUTO_INCREMENT,
    idPessoaAluno INT,
    idImagemCategoria INT,
    datahora DATETIME,
    isEnviadoResponsavel TINYINT,
    dataHoraEnvio DATETIME,
    fala VARCHAR(100),
    FOREIGN KEY (idPessoaAluno) REFERENCES PessoaAluno(idPessoaAluno),
    FOREIGN KEY (idImagemCategoria) REFERENCES imagemCategoria(idImagemCategoria)
);






describe imagemCategoria;